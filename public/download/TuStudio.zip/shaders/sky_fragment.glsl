#version 460 core

in vec3 TexCoords;
out vec4 FragColor;

uniform float time;

uniform vec3 skyTopColor;
uniform vec3 skyHorizonColor;

uniform vec3 sunDirection;
uniform vec3 sunColor;
uniform float sunIntensity;

uniform bool enableStars;
uniform float starBrightness;

float hash(vec3 p) {
    p = fract(p * 0.3183099 + 0.1);
    p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

float noise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    return mix(
        mix(mix(hash(i), hash(i + vec3(1,0,0)), f.x),
            mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),
        mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x),
            mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y),
        f.z
    );
}

float fbm(vec3 p) {
    float value = 0.0;
    float amplitude = 0.5;
    for (int i = 0; i < 5; i++) {
        value += amplitude * noise(p);
        p *= 2.0;
        amplitude *= 0.5;
    }
    return value;
}

float starField(vec3 dir) {
    vec3 p = dir * 100.0;
    float stars = 0.0;
    
    for (int i = 0; i < 3; i++) {
        vec3 q = floor(p);
        vec3 f = fract(p);
        
        float h = hash(q);
        if (h > 0.95) {
            float brightness = (h - 0.95) * 20.0;
            float dist = length(f - 0.5);
            stars += brightness * smoothstep(0.1, 0.0, dist);
        }
        
        p *= 2.0;
    }
    
    return stars;
}

void main() {
    vec3 dir = normalize(TexCoords);
    
    float gradient = pow(abs(dir.y), 0.6);
    vec3 skyColor = mix(skyHorizonColor, skyTopColor, gradient);
    
    vec3 celestialDir = normalize(sunDirection);
    float celestialDot = max(dot(dir, celestialDir), 0.0);
    
    float disc = smoothstep(0.995, 0.998, celestialDot);
    float glow = pow(celestialDot, 4.0) * 0.15;
    
    vec3 celestial = sunColor * sunIntensity * (disc + glow);
    
    float cloudOpacity = smoothstep(0.0, 0.3, sunIntensity);
    vec3 cloudPos = dir / max(abs(dir.y) + 0.15, 0.15);
    cloudPos += vec3(time * 0.005, 0.0, time * 0.003);
    
    float clouds = fbm(cloudPos * 0.8);
    clouds = smoothstep(0.45, 0.65, clouds);
    clouds *= smoothstep(0.0, 0.3, abs(dir.y));
    clouds *= cloudOpacity;
    
    vec3 cloudColor = vec3(1.0);
    
    vec3 stars = vec3(0.0);
    if (enableStars && dir.y > 0.0) {
        float starIntensity = starField(dir);
        starIntensity *= starBrightness;
        starIntensity *= (1.0 - sunIntensity);
        starIntensity *= smoothstep(0.0, 0.1, dir.y);
        stars = vec3(starIntensity);
    }
    
    vec3 finalColor = skyColor;
    finalColor = mix(finalColor, cloudColor, clouds * 0.8);
    finalColor += celestial;
    finalColor += stars;
    
    FragColor = vec4(finalColor, 1.0);
}