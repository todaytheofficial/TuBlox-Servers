#version 460 core

in vec3 FragPos;
in vec3 Normal;
in float WaveHeight;
in vec4 FragPosLightSpace;

out vec4 FragColor;

uniform vec3 viewPos;
uniform vec3 lightPos;
uniform float time;
uniform sampler2DShadow shadowMap;

float calcShadow(vec4 fragPosLS)
{
    vec3 projCoords = fragPosLS.xyz / fragPosLS.w;
    projCoords = projCoords * 0.5 + 0.5;

    if (projCoords.z > 1.0)
        return 0.0;

    float shadow = 0.0;
    vec2 texelSize = 1.0 / textureSize(shadowMap, 0);
    float bias = 0.003;

    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 offset = vec2(x, y) * texelSize;
            shadow += 1.0 - texture(shadowMap, vec3(projCoords.xy + offset, projCoords.z - bias));
        }
    }
    shadow /= 9.0;

    return shadow;
}

void main()
{
    vec3 norm = normalize(Normal);

    vec3 deepColor = vec3(0.05, 0.2, 0.4);
    vec3 shallowColor = vec3(0.1, 0.5, 0.7);
    float depthFactor = smoothstep(-0.15, 0.15, WaveHeight);
    vec3 waterColor = mix(deepColor, shallowColor, depthFactor);

    vec3 ambient = 0.3 * waterColor;

    vec3 lightDir = normalize(lightPos - FragPos);
    float diff = max(dot(norm, lightDir), 0.0);
    vec3 diffuse = diff * vec3(0.8, 0.9, 1.0) * 0.6;

    vec3 viewDir = normalize(viewPos - FragPos);
    vec3 halfDir = normalize(lightDir + viewDir);
    float spec = pow(max(dot(norm, halfDir), 0.0), 128.0);
    vec3 specular = spec * vec3(1.0, 1.0, 1.0) * 1.2;

    float fresnel = pow(1.0 - max(dot(viewDir, norm), 0.0), 3.0);
    vec3 reflectColor = vec3(0.5, 0.7, 0.9);

    float shadow = calcShadow(FragPosLightSpace);

    vec3 finalColor = ambient + (1.0 - shadow) * (diffuse * waterColor + specular);
    finalColor = mix(finalColor, reflectColor, fresnel * 0.4);

    float alpha = 0.75 + fresnel * 0.2;

    FragColor = vec4(finalColor, alpha);
}