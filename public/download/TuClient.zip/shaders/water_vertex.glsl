#version 460 core

layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aNormal;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;
uniform mat4 lightSpaceMatrix;
uniform float time;

out vec3 FragPos;
out vec3 Normal;
out float WaveHeight;
out vec4 FragPosLightSpace;

void main()
{
    vec3 pos = aPos;

    float wave1 = sin(pos.x * 1.5 + time * 2.0) * 0.08;
    float wave2 = sin(pos.z * 2.0 + time * 1.5) * 0.06;
    float wave3 = sin((pos.x + pos.z) * 1.0 + time * 2.5) * 0.04;
    float wave4 = sin(pos.x * 3.0 + pos.z * 2.0 + time * 3.0) * 0.03;

    pos.y += wave1 + wave2 + wave3 + wave4;
    WaveHeight = pos.y;

    float dx = 1.5 * cos(pos.x * 1.5 + time * 2.0) * 0.08
             + 1.0 * cos((pos.x + pos.z) * 1.0 + time * 2.5) * 0.04
             + 3.0 * cos(pos.x * 3.0 + pos.z * 2.0 + time * 3.0) * 0.03;

    float dz = 2.0 * cos(pos.z * 2.0 + time * 1.5) * 0.06
             + 1.0 * cos((pos.x + pos.z) * 1.0 + time * 2.5) * 0.04
             + 2.0 * cos(pos.x * 3.0 + pos.z * 2.0 + time * 3.0) * 0.03;

    vec3 normal = normalize(vec3(-dx, 1.0, -dz));

    vec4 worldPos = model * vec4(pos, 1.0);
    FragPos = worldPos.xyz;
    Normal = mat3(transpose(inverse(model))) * normal;
    FragPosLightSpace = lightSpaceMatrix * worldPos;

    gl_Position = projection * view * worldPos;
}