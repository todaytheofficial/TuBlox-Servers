#version 460 core

in vec3 FragPos;
in vec3 Normal;
in vec2 TexCoord;
in float IsTopFace;
in vec4 FragPosLightSpace;

out vec4 FragColor;

uniform vec3 viewPos;
uniform vec3 lightPos;
uniform vec3 lightColor;
uniform sampler2DShadow shadowMap;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(
        mix(hash(i), hash(i + vec2(1, 0)), f.x),
        mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x),
        f.y
    );
}

float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 3; i++) {
        v += a * noise(p);
        p *= 2.0;
        a *= 0.5;
    }
    return v;
}

float voronoi(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    float minDist = 1.0;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 neighbor = vec2(float(x), float(y));
            vec2 point = hash(i + neighbor) * vec2(0.8, 0.8) + 0.1;
            float d = length(neighbor + point - f);
            minDist = min(minDist, d);
        }
    }
    return minDist;
}

float calcShadow(vec4 fragPosLS) {
    vec3 projCoords = fragPosLS.xyz / fragPosLS.w;
    projCoords = projCoords * 0.5 + 0.5;
    
    if (projCoords.z > 1.0)
        return 0.0;
    
    vec3 norm = normalize(Normal);
    vec3 lightDir = normalize(lightPos - FragPos);
    float bias = max(0.003 * (1.0 - dot(norm, lightDir)), 0.001);
    
    float shadow = 0.0;
    vec2 texelSize = 1.0 / textureSize(shadowMap, 0);
    
    for (int x = -2; x <= 2; x++) {
        for (int y = -2; y <= 2; y++) {
            vec2 offset = vec2(float(x), float(y)) * texelSize;
            shadow += 1.0 - texture(shadowMap, vec3(projCoords.xy + offset, projCoords.z - bias));
        }
    }
    shadow /= 25.0;
    
    return shadow;
}

vec3 robloxGrass(vec2 uv) {
    vec3 baseGreen = vec3(0.22, 0.42, 0.20);
    vec3 lightGreen = vec3(0.32, 0.52, 0.24);
    vec3 darkGreen = vec3(0.12, 0.30, 0.10);
    vec3 accentGreen = vec3(0.28, 0.48, 0.18);
    
    float largeNoise = fbm(uv * 0.8);
    float medNoise = fbm(uv * 2.5);
    float smallNoise = noise(uv * 8.0);
    float tinyNoise = noise(uv * 16.0);
    
    float cells = voronoi(uv * 3.0);
    cells = smoothstep(0.0, 0.5, cells);
    
    vec3 color = baseGreen;
    
    color = mix(color, darkGreen, smoothstep(0.35, 0.55, largeNoise) * 0.6);
    color = mix(color, lightGreen, smoothstep(0.5, 0.7, medNoise) * 0.5);
    color = mix(color, accentGreen, cells * 0.3);
    
    float blades = sin(uv.x * 25.0 + smallNoise * 3.0) * 0.5 + 0.5;
    blades *= sin(uv.y * 20.0 + smallNoise * 2.0) * 0.5 + 0.5;
    blades = pow(blades, 1.5);
    color = mix(color, lightGreen, blades * 0.15);
    
    color *= 0.92 + tinyNoise * 0.16;
    
    return color;
}

vec3 robloxDirt(vec2 uv) {
    vec3 baseBrown = vec3(0.35, 0.24, 0.16);
    vec3 darkBrown = vec3(0.22, 0.14, 0.08);
    vec3 lightBrown = vec3(0.45, 0.32, 0.22);
    vec3 grayBrown = vec3(0.32, 0.28, 0.22);
    
    float largeNoise = fbm(uv * 0.6);
    float medNoise = fbm(uv * 2.0);
    float smallNoise = noise(uv * 6.0);
    float tinyNoise = noise(uv * 15.0);
    
    float cracks = voronoi(uv * 2.5);
    cracks = 1.0 - smoothstep(0.0, 0.15, cracks);
    
    vec3 color = baseBrown;
    
    color = mix(color, darkBrown, smoothstep(0.3, 0.5, largeNoise) * 0.5);
    color = mix(color, lightBrown, smoothstep(0.5, 0.7, medNoise) * 0.4);
    color = mix(color, grayBrown, smallNoise * 0.25);
    
    color = mix(color, darkBrown * 0.7, cracks * 0.5);
    
    float pebbles = noise(uv * 12.0);
    if (pebbles > 0.75) {
        color = mix(color, grayBrown * 1.1, 0.4);
    }
    
    color *= 0.88 + tinyNoise * 0.24;
    
    return color;
}

void main()
{
    vec3 norm = normalize(Normal);
    vec2 uv = TexCoord * 4.0;
    
    vec3 surfaceColor;
    
    if (IsTopFace > 0.5) {
        surfaceColor = robloxGrass(uv);
    } else {
        surfaceColor = robloxDirt(uv);
        
        float edgeGrass = smoothstep(0.5, 1.0, TexCoord.y + 0.5);
        vec3 grassEdge = robloxGrass(uv * 0.5) * 0.9;
        surfaceColor = mix(surfaceColor, grassEdge, edgeGrass * 0.15);
    }
    
    vec3 lightDir = normalize(lightPos - FragPos);
    float diff = max(dot(norm, lightDir), 0.0);
    
    diff = diff * 0.5 + 0.5;
    
    float shadow = calcShadow(FragPosLightSpace);
    
    float ao = 0.85 + 0.15 * (IsTopFace > 0.5 ? 1.0 : 0.8);
    
    vec3 ambient = 0.35 * surfaceColor * ao;
    vec3 diffuse = diff * 0.55 * surfaceColor;
    
    vec3 viewDir = normalize(viewPos - FragPos);
    vec3 halfDir = normalize(lightDir + viewDir);
    float spec = pow(max(dot(norm, halfDir), 0.0), 16.0);
    float specStrength = IsTopFace > 0.5 ? 0.02 : 0.04;
    vec3 specular = spec * specStrength * lightColor;
    
    vec3 result = ambient + (1.0 - shadow) * (diffuse + specular);
    
    FragColor = vec4(result, 1.0);
}