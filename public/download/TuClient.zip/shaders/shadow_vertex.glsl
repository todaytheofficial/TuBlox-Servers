#version 460 core
layout(location = 0) in vec3 aPos;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;
uniform mat4 shadowFlatten;

void main() {
    vec4 pos = shadowFlatten * model * vec4(aPos, 1.0);
    gl_Position = projection * view * pos;
}