#version 460 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aTexCoords;
layout(location = 3) in ivec4 aBoneIDs;
layout(location = 4) in vec4 aWeights;
out vec3 FragPos;
out vec3 Normal;
out vec2 TexCoords;
out vec4 FragPosLightSpace;
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;
uniform mat4 lightSpaceMatrix;
const int MAX_BONES = 100;
uniform mat4 boneMatrices[MAX_BONES];
void main() {
    mat4 skinMatrix = mat4(0.0);
    for (int i = 0; i < 4; i++) {
        if (aBoneIDs[i] >= 0 && aBoneIDs[i] < MAX_BONES) {
            skinMatrix += boneMatrices[aBoneIDs[i]] * aWeights[i];
        }
    }
    float totalWeight = aWeights[0] + aWeights[1] + aWeights[2] + aWeights[3];
    if (totalWeight < 0.01) {
        skinMatrix = mat4(1.0);
    }
    vec4 skinnedPos = skinMatrix * vec4(aPos, 1.0);
    vec4 skinnedNormal = skinMatrix * vec4(aNormal, 0.0);
    vec4 worldPos = model * skinnedPos;
    FragPos = worldPos.xyz;
    Normal = mat3(transpose(inverse(model))) * skinnedNormal.xyz;
    TexCoords = aTexCoords;
    FragPosLightSpace = lightSpaceMatrix * worldPos;
    gl_Position = projection * view * worldPos;
}