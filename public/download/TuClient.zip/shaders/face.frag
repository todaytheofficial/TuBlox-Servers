#version 330 core

in vec2 TexCoords;
in vec3 Normal;
in vec3 FragPos;

out vec4 FragColor;

uniform sampler2D faceTexture;
uniform vec3 lightPos;
uniform vec3 lightColor;

void main() {
    vec4 texColor = texture(faceTexture, TexCoords);

    if (texColor.a < 0.1) {
        discard;
    }
    
    vec3 norm = normalize(Normal);
    vec3 lightDir = normalize(lightPos - FragPos);
    
    float ambient = 0.5;
    float diff = max(dot(norm, lightDir), 0.0) * 0.5;
    
    vec3 result = (ambient + diff) * texColor.rgb * lightColor;
    FragColor = vec4(result, texColor.a);
}