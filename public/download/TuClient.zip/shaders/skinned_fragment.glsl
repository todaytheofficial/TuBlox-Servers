#version 460 core

out vec4 FragColor;

in vec3 FragPos;
in vec3 Normal;
in vec2 TexCoords;
in vec4 FragPosLightSpace;

uniform vec3 objectColor;
uniform vec3 viewPos;
uniform bool useTexture;
uniform sampler2D diffuseTexture;
uniform sampler2D shadowMap;
uniform vec2 textureRepeat;
uniform float opacity;  // Добавь эту строку

// Base lighting (как в lit_fragment.glsl)
uniform vec3 dirLightDirection;
uniform vec3 dirLightColor;
uniform float dirLightIntensity;
uniform vec3 ambientColor;
uniform float ambientIntensity;

// Custom lights
struct PointLight {
    vec3 position;
    vec3 color;
    float intensity;
    float range;
};

struct SpotLight {
    vec3 position;
    vec3 direction;
    vec3 color;
    float intensity;
    float range;
    float innerAngle;
    float outerAngle;
};

struct DirLight {
    vec3 direction;
    vec3 color;
    float intensity;
};

#define MAX_POINT_LIGHTS 8
#define MAX_SPOT_LIGHTS 8
#define MAX_DIR_LIGHTS 4

uniform int numPointLights;
uniform PointLight pointLights[MAX_POINT_LIGHTS];

uniform int numSpotLights;
uniform SpotLight spotLights[MAX_SPOT_LIGHTS];

uniform int numDirLights;
uniform DirLight dirLights[MAX_DIR_LIGHTS];

// Shadow calculation
float ShadowCalculation(vec4 fragPosLightSpace, vec3 normal, vec3 lightDir) {
    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
    projCoords = projCoords * 0.5 + 0.5;
    
    if (projCoords.z > 1.0) return 0.0;
    
    float closestDepth = texture(shadowMap, projCoords.xy).r;
    float currentDepth = projCoords.z;
    
    float bias = max(0.005 * (1.0 - dot(normal, lightDir)), 0.001);
    
    float shadow = 0.0;
    vec2 texelSize = 1.0 / textureSize(shadowMap, 0);
    for (int x = -1; x <= 1; ++x) {
        for (int y = -1; y <= 1; ++y) {
            float pcfDepth = texture(shadowMap, projCoords.xy + vec2(x, y) * texelSize).r;
            shadow += currentDepth - bias > pcfDepth ? 1.0 : 0.0;
        }
    }
    shadow /= 9.0;
    
    return shadow;
}

// Point light calculation
vec3 calcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir) {
    vec3 lightDir = normalize(light.position - fragPos);
    float distance = length(light.position - fragPos);
    
    if (distance > light.range) return vec3(0.0);
    
    float attenuation = 1.0 / (1.0 + 0.09 * distance + 0.032 * distance * distance);
    float rangeFalloff = 1.0 - smoothstep(light.range * 0.75, light.range, distance);
    attenuation *= rangeFalloff;
    
    float diff = max(dot(normal, lightDir), 0.0);
    
    vec3 halfwayDir = normalize(lightDir + viewDir);
    float spec = pow(max(dot(normal, halfwayDir), 0.0), 32.0);
    
    vec3 diffuse = diff * light.color;
    vec3 specular = spec * light.color * 0.3;
    
    return (diffuse + specular) * attenuation * light.intensity;
}

// Spot light calculation
vec3 calcSpotLight(SpotLight light, vec3 normal, vec3 fragPos, vec3 viewDir) {
    vec3 lightDir = normalize(light.position - fragPos);
    float distance = length(light.position - fragPos);
    
    if (distance > light.range) return vec3(0.0);
    
    float theta = dot(lightDir, normalize(-light.direction));
    float innerCos = cos(radians(light.innerAngle));
    float outerCos = cos(radians(light.outerAngle));
    float epsilon = innerCos - outerCos;
    float spotIntensity = clamp((theta - outerCos) / epsilon, 0.0, 1.0);
    
    if (spotIntensity <= 0.0) return vec3(0.0);
    
    float attenuation = 1.0 / (1.0 + 0.09 * distance + 0.032 * distance * distance);
    float rangeFalloff = 1.0 - smoothstep(light.range * 0.75, light.range, distance);
    attenuation *= rangeFalloff;
    
    float diff = max(dot(normal, lightDir), 0.0);
    
    vec3 halfwayDir = normalize(lightDir + viewDir);
    float spec = pow(max(dot(normal, halfwayDir), 0.0), 32.0);
    
    vec3 diffuse = diff * light.color;
    vec3 specular = spec * light.color * 0.3;
    
    return (diffuse + specular) * attenuation * spotIntensity * light.intensity;
}

// Directional light calculation
vec3 calcDirLight(DirLight light, vec3 normal, vec3 viewDir) {
    vec3 lightDir = normalize(-light.direction);
    
    float diff = max(dot(normal, lightDir), 0.0);
    
    vec3 halfwayDir = normalize(lightDir + viewDir);
    float spec = pow(max(dot(normal, halfwayDir), 0.0), 32.0);
    
    vec3 diffuse = diff * light.color;
    vec3 specular = spec * light.color * 0.3;
    
    return (diffuse + specular) * light.intensity;
}

void main() {
    // Base color
    vec3 baseColor = objectColor;
    
    if (useTexture) {
        vec2 uv = TexCoords * textureRepeat;
        vec4 texColor = texture(diffuseTexture, uv);
        baseColor = texColor.rgb * objectColor;
    }
    
    vec3 norm = normalize(Normal);
    vec3 viewDir = normalize(viewPos - FragPos);
    
    // ======== BASE LIGHTING ========
    
    // Ambient
    vec3 result = ambientColor * ambientIntensity;
    
    // Main directional light (sun)
    vec3 lightDir = normalize(-dirLightDirection);
    float diff = max(dot(norm, lightDir), 0.0);
    vec3 diffuse = dirLightColor * dirLightIntensity * diff;
    
    // Specular
    vec3 halfwayDir = normalize(lightDir + viewDir);
    float spec = pow(max(dot(norm, halfwayDir), 0.0), 32.0);
    vec3 specular = dirLightColor * dirLightIntensity * spec * 0.3;
    
    // Shadow
    float shadow = ShadowCalculation(FragPosLightSpace, norm, lightDir);
    
    result += (1.0 - shadow) * (diffuse + specular);
    
    // ======== CUSTOM LIGHTS ========
    
    // Point lights
    for (int i = 0; i < numPointLights; i++) {
        result += calcPointLight(pointLights[i], norm, FragPos, viewDir);
    }
    
    // Spot lights
    for (int i = 0; i < numSpotLights; i++) {
        result += calcSpotLight(spotLights[i], norm, FragPos, viewDir);
    }
    
    // Additional directional lights
    for (int i = 0; i < numDirLights; i++) {
        result += calcDirLight(dirLights[i], norm, viewDir);
    }
    
    // Final color
    FragColor = vec4(baseColor * result, opacity);
}