#version 460 core

layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aNormal;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;
uniform mat4 lightSpaceMatrix;

out vec3 FragPos;
out vec3 Normal;
out vec2 TexCoord;
out float IsTopFace;
out vec4 FragPosLightSpace;

void main()
{
    vec4 worldPos = model * vec4(aPos, 1.0);
    FragPos = worldPos.xyz;
    Normal = mat3(transpose(inverse(model))) * aNormal;
    IsTopFace = step(0.9, aNormal.y);
    FragPosLightSpace = lightSpaceMatrix * worldPos;
    
    float tile = 2.0;
    if (abs(aNormal.y) > 0.5) {
        TexCoord = FragPos.xz / tile;
    } else if (abs(aNormal.x) > 0.5) {
        TexCoord = FragPos.yz / tile;
    } else {
        TexCoord = FragPos.xy / tile;
    }
    
    gl_Position = projection * view * worldPos;
}