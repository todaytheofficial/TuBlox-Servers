#version 460 core

in vec2 UV;
out vec4 FragColor;

uniform float alpha;
uniform float time;
uniform float progress;
uniform int loadingStage;
uniform int scene;

float roundRect(vec2 uv, vec2 pos, vec2 size, float radius) {
    vec2 d = abs(uv - pos) - size + radius;
    return 1.0 - smoothstep(0.0, 0.003, length(max(d, 0.0)) - radius);
}

float circle(vec2 uv, vec2 pos, float radius) {
    return 1.0 - smoothstep(radius - 0.003, radius, length(uv - pos));
}

float ring(vec2 uv, vec2 pos, float radius, float thickness) {
    float dist = length(uv - pos);
    return smoothstep(radius + thickness, radius + thickness - 0.003, dist) *
           smoothstep(radius - thickness - 0.003, radius - thickness, dist);
}

void main() {
    vec3 finalColor = vec3(0.0);
    vec2 center = vec2(0.5, 0.5);
    
    if (scene == 0) {
        // ═══════════════════════════════════════════════════════════
        // UPDATE CHECK SCENE - Small centered window
        // ═══════════════════════════════════════════════════════════
        
        // Dark card background
        float card = roundRect(UV, center, vec2(0.18, 0.12), 0.015);
        finalColor += vec3(0.06) * card;
        
        // Card border
        float cardBorder = roundRect(UV, center, vec2(0.181, 0.121), 0.016) - card;
        finalColor += vec3(0.12) * max(cardBorder, 0.0);
        
        // Spinner
        float spinnerRadius = 0.025;
        float spinnerThickness = 0.004;
        vec2 spinnerPos = center + vec2(0.0, 0.02);
        
        // Base ring
        float baseRing = ring(UV, spinnerPos, spinnerRadius, spinnerThickness);
        finalColor += vec3(0.15) * baseRing;
        
        // Spinning arc
        float angle = atan(UV.y - spinnerPos.y, UV.x - spinnerPos.x);
        float rotSpeed = time * 3.5;
        float arcLength = 3.8;
        float arcStart = rotSpeed;
        
        float normAngle = mod(angle + 3.14159, 6.28318);
        float normStart = mod(arcStart, 6.28318);
        float normEnd = mod(arcStart + arcLength, 6.28318);
        
        float inArc = 0.0;
        if (normStart < normEnd) {
            inArc = step(normStart, normAngle) * step(normAngle, normEnd);
        } else {
            inArc = step(normStart, normAngle) + step(normAngle, normEnd);
        }
        
        float distFromStart = mod(normAngle - normStart + 6.28318, 6.28318);
        float arcFade = smoothstep(0.0, 0.6, distFromStart) * smoothstep(0.0, 0.6, arcLength - distFromStart);
        
        float spinner = ring(UV, spinnerPos, spinnerRadius, spinnerThickness) * inArc * arcFade;
        finalColor += vec3(1.0) * spinner;
        
        // Progress bar (during download)
        if (progress > 0.01 && loadingStage >= 2) {
            vec2 barPos = center - vec2(0.0, 0.05);
            vec2 barSize = vec2(0.12, 0.004);
            
            float barBg = roundRect(UV, barPos, barSize, 0.004);
            finalColor += vec3(0.1) * barBg;
            
            float fillWidth = barSize.x * progress;
            vec2 fillPos = vec2(barPos.x - barSize.x + fillWidth, barPos.y);
            float barFill = roundRect(UV, fillPos, vec2(fillWidth, barSize.y), 0.004);
            finalColor = mix(finalColor, vec3(0.4, 0.6, 1.0), barFill);
        }
        
    } else {
        // ═══════════════════════════════════════════════════════════
        // LOADING SCENE - Full screen with spinner
        // ═══════════════════════════════════════════════════════════
        
        // Center spinner
        float spinnerRadius = 0.04;
        float spinnerThickness = 0.006;
        
        // Base ring
        float baseRing = ring(UV, center, spinnerRadius, spinnerThickness);
        finalColor += vec3(0.12) * baseRing;
        
        // Spinning arc
        float angle = atan(UV.y - center.y, UV.x - center.x);
        float rotSpeed = time * 3.0;
        float arcLength = 4.0;
        
        float normAngle = mod(angle + 3.14159, 6.28318);
        float normStart = mod(rotSpeed, 6.28318);
        float normEnd = mod(rotSpeed + arcLength, 6.28318);
        
        float inArc = 0.0;
        if (normStart < normEnd) {
            inArc = step(normStart, normAngle) * step(normAngle, normEnd);
        } else {
            inArc = step(normStart, normAngle) + step(normAngle, normEnd);
        }
        
        float distFromStart = mod(normAngle - normStart + 6.28318, 6.28318);
        float arcFade = smoothstep(0.0, 0.5, distFromStart) * smoothstep(0.0, 0.5, arcLength - distFromStart);
        
        float spinner = ring(UV, center, spinnerRadius, spinnerThickness) * inArc * arcFade;
        finalColor += vec3(1.0) * spinner;
        
        // Progress bar below spinner
        vec2 barPos = vec2(0.5, 0.42);
        vec2 barSize = vec2(0.15, 0.004);
        
        float barBg = roundRect(UV, barPos, barSize, 0.004);
        finalColor += vec3(0.08) * barBg;
        
        if (progress > 0.005) {
            float fillWidth = barSize.x * progress;
            vec2 fillPos = vec2(barPos.x - barSize.x + fillWidth, barPos.y);
            float barFill = roundRect(UV, fillPos, vec2(fillWidth, barSize.y), 0.004);
            finalColor = mix(finalColor, vec3(1.0), barFill);
        }
    }
    
    FragColor = vec4(finalColor, alpha);
}